import logging

from flask import request, make_response, Blueprint

from model.inference import ModelCPlus
from src.core_func import ResponseStatus, FactorList

model = ModelCPlus()
request_api = Blueprint('request_api', __name__)


def get_blueprint():
    return request_api

@request_api.route("/health", methods=["GET"])
def health_check():
    return make_response(
        ResponseStatus('service is live').success_response(201)
    )

@request_api.route("/predict", methods=["POST"])
def predict():
    # check json data in request
    factor_list = FactorList.check(request.json)

    if not factor_list['status']:
        logging.info('Найдены ошибки в factor list\n')
        return make_response(
            ResponseStatus(factor_list['message']).error_response(402)
        )

    if not request.json:
        logging.info('No data passed\n')
        return make_response(
            ResponseStatus('no data passed').error_response(401)
        )

    # make prediction
    try:
        prediction = model.predict(request.json)

        if not prediction:
            logging.info('Wrong data passed\n')
            return make_response(
                ResponseStatus('wrong data passed').error_response(403)
            )
    except Exception as e:
        logging.exception(str(e))
        logging.info('Data structure error\n')
        return make_response(
            ResponseStatus('data structure error').error_response(403)
        )
    logging.info('Done\n')
    return make_response(
        ResponseStatus(prediction).predict_response(201)
    )
