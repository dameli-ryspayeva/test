from flask import jsonify


class ResponseStatus:
    """
    generate positive/negative response messages for API
    """

    def __init__(self, message):
        self.message = message

    def error_response(self, status):
        response = jsonify(
            {
                "status": "error",
                "error_code": "4",
                "message": self.message
            }
        ), status

        return response

    def success_response(self, status):
        response = jsonify(
            {
                "status": "ok",
                "error_code": "0",
                "message": self.message
            }
        ), status

        return response

    def predict_response(self, status):
        return jsonify(
            {
                "status": "ok",
                "error_code": "0",
                "prediction": self.message
            }
        ), status


class FactorList:
    """
    Check input json file for valid structure and data
    """

    @classmethod
    def check(cls, factor_list):
        error = 0
        # проверка на корректность заполнения request.json
        quals_empty = []
        quants_empty = []
        govs_empty = []
        groups_empty = []
        signals_empty = []
        result_dict = {}
        result = ''

        # качественный модуль
        for factor in factor_list['ListOfFixedFactor']:
            if factor.get('Group', 0) == "Качественные":
                if factor.get('Value', 0) == "":
                    quals_empty.append(factor.get('Factor'))
        # количественный модуль
        for period in range(len(factor_list['ListOfRatingPeriod'])):
            for factor in range(len(factor_list['ListOfRatingPeriod'][period]['ListOfCardinalFactor'])):
                if factor_list['ListOfRatingPeriod'][period]['ListOfCardinalFactor'][factor].get('NumValue', 0) == '':
                    quants_empty.append(factor_list['ListOfRatingPeriod'][period]['ListOfCardinalFactor'][factor].get(
                        'Factor', 0))

        # группа поддержки
        if factor_list['ListOfRatingSupport'][0]['ListOfSupportFactor'][0]['FreeValue'] == '':
            pass
        else:
            for factor in factor_list['ListOfRatingSupport'][0]['ListOfSupportFactor']:
                if factor['FactorIntegrationId'] == 'k_gr_name' or factor['FactorIntegrationId'] == 'k_gr_code' or factor['FactorIntegrationId'] == 'rating_id':
                    if factor.get('FreeValue', 0) == '':
                        groups_empty.append(factor.get('Factor', 0))
                elif factor.get('Value', 0) == '':
                    groups_empty.append(factor.get('Factor', 0))

        # # поддержка государства
        if factor_list['ListOfRatingSupport'][1]['ListOfSupportFactor'][0]['Value'] == '':
            pass
        else:
            for factor in factor_list['ListOfRatingSupport'][1]['ListOfSupportFactor']:
                if factor['FactorIntegrationId'] == 'k_gov_support_1' or factor['FactorIntegrationId'] == 'k_gov_support_4':
                    if factor.get('FreeValue', 0) == '':
                        govs_empty.append(factor.get('Factor', 0))
                elif factor.get('Value', 0) == '':
                    govs_empty.append(factor.get('Factor', 0))

        for factor in factor_list['ListOfFixedFactor']:
            if factor.get('Group', 0) == "Предупреждающие сигналы":
                if factor.get('Value', 0) == "":
                    signals_empty.append(factor.get('Factor'))

        result_dict['Качественный блок'] = quals_empty
        result_dict['Количественный блок'] = quants_empty
        result_dict['Блок поддержки государства'] = govs_empty
        result_dict['Блок поддержки группы'] = groups_empty
        result_dict['Блок предупреждающих сигналов'] = signals_empty
        result_dict = {k: v for k, v in result_dict.items() if v}

        for k, v in result_dict.items():
            result += ''.join(f'{k}:  ')
            for value in v:
                result += ''.join(f'{value}.  ')

        message = f'Ошибок в запросе: {len(result_dict)}. Ошибка: Параметр является обязательным и должен быть задан. {result}'
        if len(result_dict) > 0:
            error = 1

        if result_dict == {}:
            # второе сообщение об ошибке
            r = dict()
            kfx36 = 0

            for j in range(len(factor_list['ListOfRatingPeriod'])):
                for i in factor_list['ListOfRatingPeriod'][j]['ListOfCardinalFactor']:
                    r[i['FactorIntegrationId']] = float(i['NumValue'])

            for element in range(len(factor_list['ListOfFixedFactor'])):
                if factor_list['ListOfFixedFactor'][element]['FactorIntegrationId'] == "kfx36":
                    kfx36 = factor_list['ListOfFixedFactor'][element]['Value']

            if (r['k_statement_count'] >= 5.0 and kfx36.lower() == "да") or (
                    r['k_statement_count'] < 5.0 and kfx36.lower() == "нет"):
                error = 2
                message = 'Проверьте, пожалуйста, корректность заполнения показателей (Является ли компания ' \
                        'молодой?) и (Количество кварталов в Дата 1 + Дата 3 / Количество кварталов в Дата 1 + Дата 2)'
        if error == 0:
            return {
                "status": True,
                "message": factor_list
            }
        else:
            return {
                "status": False,
                "message": message
            }
