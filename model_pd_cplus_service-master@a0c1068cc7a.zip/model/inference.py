import logging
import json
import pandas as pd
from math import exp


class ModelCPlus:

    def __init__(self):
        """
        init constant weights of the model
        """
        self.message = ''

        self.TS_qual_intercept = -2.82293231538698
        self.qual_coef_woe_4 = -0.00531882423431802
        self.qual_coef_woe_7 = -0.00939238661166571
        self.qual_coef_woe_9 = -0.0100972231337422
        self.qual_coef_woe_15 = -0.0093958471538979
        self.qual_coef_woe_21 = -0.00642458995078634
        self.qual_coef_woe_31 = -0.00923207503444487

        self.TS_quant_intercept = -2.86291872375434
        self.debt_ratio_woe = -0.521863070229631
        self.interest_coverage_ratio_woe = -0.642296539071975
        self.asset_turnover_ratio_woe = -0.682919786021013
        self.cash_ratio_woe = -0.450264916930864
        self.earn_growth_woe = -0.674747741991609
        self.net_working_capital_to_short_tearm_debt = -0.338568201752662

        self.TS_total_intercept = 1.76123590621228
        self.TS_quant_coeff = 0.793804502286527
        self.TS_qual_coeff = 0.839669578559788

        self.beta0_TTC = -0.80884332
        self.beta1_TTC = 0.74718405
        self.beta0_PIT = -0.36559583
        self.beta1_PIT = 0.93888866

        self.lower_limit = [
            0.000 / 100, 0.032 / 100, 0.044 / 100, 0.060 / 100, 0.083 / 100,
            0.114 / 100, 0.156 / 100, 0.215 / 100, 0.297 / 100, 0.409 / 100,
            0.563 / 100, 0.775 / 100, 1.067 / 100, 1.470 / 100, 2.024 / 100,
            2.788 / 100, 3.839 / 100, 5.287 / 100, 7.280 / 100, 10.026 / 100,
            13.807 / 100, 19.014 / 100, 26.185 / 100, 36.059 / 100, 49.659 / 100, 100 / 100
        ]

        self.upper_limit = [
            0.032 / 100, 0.044 / 100, 0.060 / 100, 0.083 / 100, 0.114 / 100,
            0.156 / 100, 0.215 / 100, 0.297 / 100, 0.409 / 100, 0.563 / 100,
            0.775 / 100, 1.067 / 100, 1.470 / 100, 2.024 / 100, 2.788 / 100,
            3.839 / 100, 5.287 / 100, 7.280 / 100, 10.026 / 100, 13.807 / 100,
            19.014 / 100, 26.185 / 100, 36.059 / 100, 49.659 / 100, 100.000 / 100,
            100.000 / 100
        ]

        self.default = [
            0.02 / 100, 0.037 / 100, 0.051 / 100, 0.07 / 100, 0.097 / 100,
            0.133 / 100, 0.184 / 100, 0.253 / 100, 0.348 / 100, 0.48 / 100,
            0.66 / 100, 0.91 / 100, 1.253 / 100, 1.725 / 100, 2.375 / 100,
            3.271 / 100, 4.505 / 100, 6.204 / 100, 8.543 / 100, 11.765 / 100,
            16.203 / 100, 22.313 / 100, 30.728 / 100, 42.316 / 100, 58.275 / 100,
            100.000 / 100
        ]

        self.ratings = [
            1, 2, 3, 4, 5, 6, 7, 8,
            9, 10, 11, 12, 13, 14, 15,
            16, 17, 18, 19, 20, 21, 22,
            23, 24, 25, 26
        ]

        self.master = pd.DataFrame({'lower': self.lower_limit, 'upper': self.upper_limit, 'rating': self.ratings,
                                    'default': self.default})

        self.fitch = {
            "Aaa": 0.0002, "Aa1": 0.0002, "Aa2": 0.0002, "Aa3": 0.0002, "A1": 0.0002, "A2": 0.00037, "A3": 0.00051,
            "Baa1": 0.00097, "Baa2": 0.00184, "Baa3": 0.00253, "Ba1": 0.0048, "Ba2": 0.0091, "Ba3": 0.01253,
            "B1": 0.02375, "B2": 0.03271, "B3": 0.06204, "Caa1": 0.08543, "Caa2": 0.16203, "Caa3": 0.22313,
            "Ca": 0.30728, "C": 0.42316}

        self.fitchrating = {
            "Aaa": 1, "Aa1": 1, "Aa2": 1, "Aa3": 1, "A1": 1, "A2": 2, "A3": 3,
            "Baa1": 5, "Baa2": 7, "Baa3": 8, "Ba1": 10, "Ba2": 12, "Ba3": 13,
            "B1": 15, "B2": 16, "B3": 18, "Caa1": 19, "Caa2": 21, "Caa3": 22,
            "Ca": 23, "C": 24}

        self.minrating = 8
        self.CAP_TTC = 8
        self.CAP_PIT = 8
        self.FEDERAL_RATING = 8

        self.max_target = 26
        self.max_notch = 25

        sensor_factors = {
            "target":
                {
                    17: ["kws26"],
                    19: ["kws27"],
                    23: ["kws9", "5_15_dpd"],
                    24: ["kws18"],
                    25: ["kws10", "kws14", "16_29_dpd"],
                    26: ["kws25", "DT0100", "DT0200", "DT0400", "DT0500", "DT0600", "DT0700", "DT0700_1",
                         "DT0700_2", "DT0700_3", "DT0700_4", "DT0700_5", "DT0700_6", "DT0700_7", "DT0700_8",
                         "DT0700_9", "DT0700_10", "DT0800", "DT0900", "DT1000", "DT1000_1"]
                },
            "notch":
                {
                    2: ["kws1", "kws2", "kws3", "kws17"],
                    3: ["kws4"],
                    5: ["kws7", "kws11", "kws12"],
                    8: ["kws5", "kws8"]
                }
        }

        self.sensor_target = {}
        self.sensor_notch = {}

        for key, value_list in sensor_factors['target'].items():
            sensor = {value: key for value in value_list}
            self.sensor_target.update(sensor)

        for key, value_list in sensor_factors['notch'].items():
            sensor = {value: key for value in value_list}
            self.sensor_notch.update(sensor)

    # Моудль расчета качественного блока
    def quality_module(self, raw) -> float:
        with open('dictionary/quality.json') as json_file:
            conf = json.load(json_file)
            d = dict()
            for element in range(len(raw['ListOfFixedFactor'])):
                if raw['ListOfFixedFactor'][element]['FactorIntegrationId'] in conf:
                    d[raw['ListOfFixedFactor'][element]['FactorIntegrationId']] = \
                        conf[raw['ListOfFixedFactor'][element]['FactorIntegrationId']][
                            raw['ListOfFixedFactor'][element]['ValueIntegrationId']]

            kfx4_score = d['kfx4']
            kfx22_score = d['kfx22']
            kfx15_score = d['kfx15']
            kfx31_score = d['kfx31']
            kfx9_score = d['kfx9']
            kfx7_score = d['kfx7']

            TS_qual = self.TS_qual_intercept + (self.qual_coef_woe_4 * kfx4_score) + (self.qual_coef_woe_21 * kfx22_score) \
                      + (self.qual_coef_woe_15 * kfx15_score) + (self.qual_coef_woe_31 * kfx31_score) + (
                              self.qual_coef_woe_9 * kfx9_score + self.qual_coef_woe_7 * kfx7_score)

            logging.info("quality_module calculated")

            return TS_qual

    # Модуль расчет фактора молодой компании
    def is_young_or_no(self, a, raw) -> bool:
        kfx36 = 0
        for element in range(len(raw['ListOfFixedFactor'])):
            if raw['ListOfFixedFactor'][element]['FactorIntegrationId'] == "kfx36":
                kfx36 = raw['ListOfFixedFactor'][element]['Value']

        if a['k_statement_count'] >= 5 and kfx36.lower() == "нет":
            return False
        elif a['k_statement_count'] < 5 and kfx36.lower() == "да":
            return True

    # Модуль расчета количественного модуля
    def quantitative_score(self, qual_features_dict: dict) -> dict:
        with open('dictionary/quantitative.json') as json_file:
            q = json.load(json_file)

        with open('dictionary/quantitative_score.json') as json_file:
            score = json.load(json_file)

        mapped_dict = {}
        for j in qual_features_dict:
            categories = q[j]
            for i in range(len(categories)):
                if categories[i][0] <= qual_features_dict[j] < categories[i][1]:
                    mapped_dict[j] = score[j][str(categories[i][0])]
        return mapped_dict

    def quantitative_module(self, raw) -> dict:
        a = dict()
        qual_features_dict = dict()
        k_rev = 0
        for j in range(len(raw['ListOfRatingPeriod'])):
            for i in raw['ListOfRatingPeriod'][j]['ListOfCardinalFactor']:
                a[i['FactorIntegrationId']] = float(i['NumValue'])

        qual_features_dict['debt_ratio'] = (a['k_short_liab_q1'] + a['k_long_liab_q1']) / max(a['k_asset_q1'], 0.01)
        qual_features_dict['interest_coverage_ratio'] = a['k_op_prof_q1'] / max(a['k_fin_exp_q1'], 0.01)

        if self.is_young_or_no(a, raw):
            if 'k_rev_y' in a:
                k_rev = (a['k_rev_q1'] + a['k_rev_y']) * (4 / a['k_statement_count'])
            else:
                k_rev = a['k_rev_q1'] * (4 / a['k_statement_count'])
        else:
            if 'k_rev_y' in a:
                k_rev = a['k_rev_q1'] + a['k_rev_y'] - a['k_rev_q2']
            else:
                k_rev = a['k_rev_q1']

        qual_features_dict['asset_turnover_ratio'] = k_rev / max(((a['k_asset_q1'] + a['k_asset_q2']) / 2), 0.01)
        qual_features_dict['net_working_capital_to_short_tearm_debt'] = (a['k_cur_asset_q1'] - a['k_short_liab_q1']) / max(a['k_short_debt_q1'], 0.01)
        qual_features_dict['earn_growth'] = a['k_rev_q1'] / max(a['k_rev_q2'], 0.01)
        qual_features_dict['cash_ratio'] = a['k_cash_q1'] / max(a['k_short_liab_q1'], 0.01)

        # вызываем функцию quantitative_score для вычисления score
        mapped_dict = self.quantitative_score(qual_features_dict)

        debt_ratio_score = mapped_dict['debt_ratio']
        interest_coverage_ratio_score = mapped_dict['interest_coverage_ratio']
        asset_turnover_ratio_score = mapped_dict['asset_turnover_ratio']
        net_working_capital_to_total_debt_score = mapped_dict['net_working_capital_to_short_tearm_debt']
        earn_growth_score = mapped_dict['earn_growth']
        cash_ratio_score = mapped_dict['cash_ratio']

        TS_quant = debt_ratio_score * self.debt_ratio_woe + interest_coverage_ratio_score * self.interest_coverage_ratio_woe \
                   + asset_turnover_ratio_score * self.asset_turnover_ratio_woe \
                   + net_working_capital_to_total_debt_score * self.net_working_capital_to_short_tearm_debt \
                   + earn_growth_score * self.earn_growth_woe + cash_ratio_score * self.cash_ratio_woe \
                   + self.TS_quant_intercept

        TS_qual = self.quality_module(raw)

        TS_TOTAL = TS_qual * self.TS_qual_coeff + TS_quant * self.TS_quant_coeff + self.TS_total_intercept

        PD_standalone_TTC = 1 / (1 + exp(-(self.beta0_TTC + self.beta1_TTC * TS_TOTAL)))
        PD_standalone_PIT = 1 / (1 + exp(-(self.beta0_PIT + self.beta1_PIT * TS_TOTAL)))

        # Расчеты промежуточного рейтинга
        rating_TTC = self.master[
            (self.master.lower <= PD_standalone_TTC) & (self.master.upper > PD_standalone_TTC)].rating.values[0]

        rating_PIT = self.master[
            (self.master.lower <= PD_standalone_PIT) & (self.master.upper > PD_standalone_PIT)].rating.values[0]

        R_standalone_TTC = max(rating_TTC, self.CAP_TTC)
        R_standalone_PIT = max(rating_PIT, self.CAP_PIT)

        return {"PD_standalone_TTC": PD_standalone_TTC, "PD_standalone_PIT": PD_standalone_PIT,
                "TS_quant": TS_quant, "R_standalone_TTC": R_standalone_TTC,
                "R_standalone_PIT": R_standalone_PIT, "a": a}

    # Модуль поддержки группы и поддержки государства
    def gr_gos_support_module(self, raw) -> dict:

        with open('dictionary/group_gossupport.json') as json_file:
            conf = json.load(json_file)

        key = ""
        w_a = 0.0
        w_w = 0.0
        kgs_sum = 0.0

        # поддержка группы
        # W_a
        for j in raw['ListOfRatingSupport'][0]['ListOfSupportFactor']:
            for value in j.values():
                if value == 'kgrs1':
                    key += j['ValueIntegrationId']
                elif value == 'kgrs2':
                    key += j['ValueIntegrationId']
                # W_w
                if value in conf['W_w'][0].keys() and j['ValueIntegrationId'].lower() == 'y':
                    w_w += conf['W_w'][0][value]
                    w_w = float(w_w)

        if key is (None or "") or len(key) != 2:
            pass
        else:
            w_a = conf['W_a'][0][key]
            w_a = float(w_a)

        # W_gr итоговый вес групповой подержки
        if (w_w * w_a) == 0.0:
            w_gr = 0.0
        else:
            w_gr = min(0.9, w_w * w_a)
            w_gr = round(w_gr, 2)

        # гос поддержка
        # w_gov
        gov_r = {}
        for i in raw['ListOfRatingSupport'][1]['ListOfSupportFactor']:
            if i.get('FactorIntegrationId') == 'k_gov_support_2' or i.get(
                    'FactorIntegrationId') == 'k_gov_support_3':
                gov_r[i.get('FactorIntegrationId')] = i.get('ValueIntegrationId')
            for value in i.values():
                if value in conf['W_gov'][0].keys():
                    if i['ValueIntegrationId'] is None or i['ValueIntegrationId'] == "":
                        kgs_sum = 0.0
                    else:
                        kgs_sum += conf['W_gov'][0][value][i['ValueIntegrationId']]
                        kgs_sum = float(kgs_sum)
        if kgs_sum == 0.0:
            w_gov = 0.0
        else:
            w_gov = min(0.9, kgs_sum)

        if gov_r['k_gov_support_2'] != '':
            k_gos_int_rating = int(gov_r['k_gov_support_2'])
            if k_gos_int_rating < self.minrating:
                PD_gov_int = self.master[(self.master.rating == self.minrating)].default.values[0]
            else:
                PD_gov_int = self.master[(self.master.rating == k_gos_int_rating)].default.values[0]
        else:
            PD_gov_int = self.master[(self.master.rating == self.minrating)].default.values[0]

        if gov_r['k_gov_support_3'] != '':
            for key, value in self.fitchrating.items():
                if gov_r['k_gov_support_3'] in key:
                    k_group_ext_rating = value
                    if k_group_ext_rating < self.minrating:
                        PD_gov_ext = self.master[(self.master.rating == self.minrating)].default.values[0]
                    else:
                        for k, v in self.fitch.items():
                            if gov_r['k_gov_support_3'] == k:
                                PD_gov_ext = v
        else:
            PD_gov_ext = self.master[(self.master.rating == self.minrating)].default.values[0]

        PD_gov_prob = max(PD_gov_int, PD_gov_ext)

        if PD_gov_prob == 0:
            PD_gov_prob = self.master[(self.master.rating == self.FEDERAL_RATING)].default.values[0]

        # Расчет рейтинга
        PD_standalone_TTC = self.quantitative_module(raw)['PD_standalone_TTC']
        PD_standalone_PIT = self.quantitative_module(raw)['PD_standalone_PIT']

        r = dict()
        for factor in raw['ListOfRatingSupport'][0]['ListOfSupportFactor']:
            if factor.get('FactorIntegrationId') == 'k_group_int_rating' or factor.get(
                    'FactorIntegrationId') == 'k_group_ext_rating':
                r[factor.get('FactorIntegrationId')] = factor.get('ValueIntegrationId')

        if r['k_group_int_rating'] != '':
            k_group_int_rating = int(r['k_group_int_rating'])
            if k_group_int_rating < self.minrating:
                PD_gr_int = self.master[(self.master.rating == self.minrating)].default.values[0]
            else:
                PD_gr_int = self.master[(self.master.rating == k_group_int_rating)].default.values[0]
        else:
            PD_gr_int = self.master[(self.master.rating == self.minrating)].default.values[0]

        if r['k_group_ext_rating'] != '':
            for key, value in self.fitchrating.items():
                if r['k_group_ext_rating'] in key:
                    k_group_ext_rating = value
                    if k_group_ext_rating < self.minrating:
                        PD_gr_ext = self.master[(self.master.rating == self.minrating)].default.values[0]
                    else:
                        for k, v in self.fitch.items():
                            if r['k_group_ext_rating'] == k:
                                PD_gr_ext = v
        else:
            PD_gr_ext = self.master[(self.master.rating == self.minrating)].default.values[0]

        PD_gr = max(PD_gr_int, PD_gr_ext)

        # Расчет PD_gg для TTC и PIT:
        PD_gg_TTC = 0
        PD_gg_PIT = 0
        if PD_standalone_TTC <= PD_gr:
            PD_gg_TTC = PD_standalone_TTC
        elif PD_standalone_TTC > PD_gr:
            PD_gg_TTC = w_gr * PD_gr + PD_standalone_TTC * (1 - w_gr)

        if PD_standalone_PIT <= PD_gr:
            PD_gg_PIT = PD_standalone_PIT
        elif PD_standalone_PIT > PD_gr:
            PD_gg_PIT = w_gr * PD_gr + PD_standalone_PIT * (1 - w_gr)

        PD_gg_TTC_r = self.master[(self.master.lower <= PD_gg_TTC) & (self.master.upper > PD_gg_TTC)].rating.values[0]
        PD_gg_PIT_r = self.master[(self.master.lower <= PD_gg_PIT) & (self.master.upper > PD_gg_PIT)].rating.values[0]

        # Расчет показателя PD_gov:
        PD_gov_TTC = 0
        PD_gov_PIT = 0
        if PD_gg_TTC <= PD_gov_prob:
            PD_gov_TTC = PD_gg_TTC
        elif PD_gg_TTC > PD_gov_prob:
            PD_gov_TTC = w_gov * PD_gov_prob + PD_gg_TTC * (1 - w_gov)

        if PD_gg_PIT <= PD_gov_prob:
            PD_gov_PIT = PD_gg_PIT
        elif PD_gg_PIT > PD_gov_prob:
            PD_gov_PIT = w_gov * PD_gov_prob + PD_gg_PIT * (1 - w_gov)

        PD_Total_TTC = self.master[(self.master.lower <= PD_gov_TTC) & (self.master.upper > PD_gov_TTC)].rating.values[0]
        PD_Total_PIT = self.master[(self.master.lower <= PD_gov_PIT) & (self.master.upper > PD_gov_PIT)].rating.values[0]

        Rating_total_TTC = PD_Total_TTC
        Rating_total_PIT = PD_Total_PIT

        a = self.quantitative_module(raw)['a']
        if self.is_young_or_no(a, raw):
            if Rating_total_TTC < 20 and Rating_total_PIT < 20:
                Rating_total_TTC = 20
                Rating_total_PIT = 20
            elif Rating_total_TTC > 20 and Rating_total_PIT > 20:
                Rating_total_TTC = (max(20, Rating_total_TTC))
                Rating_total_PIT = (max(20, Rating_total_PIT))

        return {"Rating_total_TTC": Rating_total_TTC, "Rating_total_PIT": Rating_total_PIT,
                "PD_gg_TTC": PD_gg_TTC_r, "PD_gg_PIT": PD_gg_PIT_r,
                "PD_gov_TTC": PD_gov_TTC, "PD_gov_PIT": PD_gov_PIT}

    def sensor_factor_check(self, raw) :
        """
        :param raw:
        :param sensors:
        :param Rating_total_TTC, Rating_total_PIT :
        :return: updated Rating_total_TTC, Rating_total_PIT

        Check for sensors predict and notch.
        if predict - immediate return value equal dict
        if notch -  return pd score + sum of notch factors
        """
        gr_gos_support = self.gr_gos_support_module(raw)
        Rating_total_TTC = gr_gos_support['Rating_total_TTC']
        Rating_total_PIT = gr_gos_support['Rating_total_PIT']

        sensors = raw['RateFactors']
        active_sensor = [key for key, value in sensors.items() if value != 'n']
        if not active_sensor:
            return Rating_total_TTC, Rating_total_PIT

        target_value = [0]
        notch_value = [0]

        for sensor in active_sensor:
            if sensor in self.sensor_target.keys():
                target_value.append(self.sensor_target[sensor])
            elif sensor in self.sensor_notch.keys():
                notch_value.append(self.sensor_notch[sensor])

        target_value = max(target_value)
        notch_value = sum(notch_value)

        TOTAL_TTC = max(target_value, min(self.max_notch, Rating_total_TTC + notch_value))
        TOTAL_PIT = max(target_value, min(self.max_notch, Rating_total_PIT + notch_value))
                
        return TOTAL_TTC, TOTAL_PIT

    def predict(self, raw) -> dict:

        TS_qual = self.quality_module(raw)

        quantitative = self.quantitative_module(raw)
        TS_quant = quantitative['TS_quant']
        R_standalone_TTC = quantitative['R_standalone_TTC']
        R_standalone_PIT = quantitative['R_standalone_PIT']

        gr_gos_support = self.gr_gos_support_module(raw)
        PD_gg_TTC = gr_gos_support['PD_gg_TTC']
        PD_gg_PIT = gr_gos_support['PD_gg_PIT']

        TOTAL_TTC, TOTAL_PIT = self.sensor_factor_check(raw)

        Rating_total_TTC = gr_gos_support['Rating_total_TTC']
        Rating_total_PIT = gr_gos_support['Rating_total_PIT']

        Rqual = exp(TS_qual) / (1 + exp(TS_qual))
        Rquant = exp(TS_quant) / (1 + exp(TS_quant))

        Rqual_r = self.master[(self.master.lower <= Rqual) & (self.master.upper > Rqual)].rating.values[0]
        Rquant_r = self.master[(self.master.lower <= Rquant) & (self.master.upper > Rquant)].rating.values[0]

        TOTAL_TTC = max(TOTAL_TTC, self.CAP_TTC)
        TOTAL_PIT = max(TOTAL_PIT, self.CAP_PIT)

        return {
            "ListofResultRating": 
            [
                {
                    "IsPrimary" : "N",
                    "Name": "Rqual",
                    "Value": str(Rqual_r),
                    "Type" : ""
                },
                {
                    "IsPrimary": "N",
                    "Name": "Rquant",
                    "Value": str(Rquant_r),
                    "Type": ""
                },
                {
                    "IsPrimary": "N",
                    "Name": "Rstandalone_TTC",
                    "Value": str(R_standalone_TTC),
                    "Type": ""
                },
                {
                    "IsPrimary": "N",
                    "Name": "Rstandalone_PIT",
                    "Value": str(R_standalone_PIT),
                    "Type": ""
                },
                {
                    "IsPrimary": "N",
                    "Name": "Rgg",
                    "Value": str(PD_gg_TTC),
                    "Type": ""
                },
                {
                    "IsPrimary": "N",
                    "Name": "Rgg_price",
                    "Value": str(PD_gg_PIT),
                    "Type": ""
                },
                {
                    "IsPrimary": "Y",
                    "Name": "Rw",
                    "Value": str(TOTAL_TTC),
                    "Type": "Рейтинг"
                },
                {
                    "IsPrimary": "N",
                    "Name": "Rw_price",
                    "Value": str(TOTAL_PIT),
                    "Type": ""
                },
                {
                    "IsPrimary": "N",
                    "Name": "RATING_REZERV_TTC",
                    "Value": str(Rating_total_TTC),
                    "Type": ""
                },
                {
                    "IsPrimary": "N",
                    "Name": "RATING_REZERV_PIT",
                    "Value": str(Rating_total_PIT),
                    "Type": ""
                }
            ]
        }