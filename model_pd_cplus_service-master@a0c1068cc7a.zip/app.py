from flask import Flask
from routes.request_api import get_blueprint

app = Flask(__name__)
app.register_blueprint(get_blueprint())

if __name__ == '__main__':
    app.run('localhost', port=5000)